const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('lennonNative', {
  openPip: () => ipcRenderer.send('pip:open'),
  closePip: () => ipcRenderer.send('pip:close'),
  updatePip: (state) => ipcRenderer.send('pip:update', state),
  sendPipFiles: (paths) => ipcRenderer.send('pip:add-files', paths),
  getPathForFile: (file) => webUtils.getPathForFile(file),
  readLocalFile: (filePath) => ipcRenderer.invoke('file:read', filePath),
  writeLocalFile: (filePath, data) => ipcRenderer.invoke('file:write', filePath, data),
  onPipFiles: (callback) => ipcRenderer.on('pip:add-files', (_event, paths) => callback(paths)),
  onPipUpdate: (callback) => ipcRenderer.on('pip:update', (_event, state) => callback(state)),
  onPipReady: (callback) => ipcRenderer.on('pip:ready', callback),
  onPipClosed: (callback) => ipcRenderer.on('pip:closed', callback)
});
