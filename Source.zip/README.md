# Lennon Audio Player para Windows

Este projeto empacota o player web original como um aplicativo Windows nativo usando Electron. A interface, o equalizador, os visualizadores, o arrastar e soltar e a reprodução local de áudio permanecem no arquivo `index.html`.

## Arrastar arquivos e pastas

A tela principal aceita arquivos de áudio e pastas arrastados do Explorador de Arquivos do Windows. Pastas são percorridas recursivamente, incluindo subpastas. São aceitos MP3, WAV, OGG, M4A, AAC e FLAC.

## Editar e salvar ID3v1

Na playlist, clique com o botão direito sobre uma música e escolha **Editar tag**. É possível alterar título, artista e álbum. O botão **Save tags** grava os dados diretamente no arquivo local, respeitando o limite de 30 caracteres de cada campo. Esse recurso está disponível para arquivos locais dentro do aplicativo Windows.

## Executar em desenvolvimento

```bash
npm install
npm start
```

## Gerar o executável portátil

```bash
npm run dist:win
```

O comando gera em `dist` o arquivo `Lennon-Audio-Player-1.0.0-x64.exe`. Ele pode ser aberto diretamente no Windows, sem instalação.

## Gerar instalador tradicional

```bash
npm run dist:win:installer
```

Esse comando gera um instalador NSIS com atalhos no menu Iniciar e na área de trabalho. Em Linux, o Electron Builder precisa do Wine instalado para gerar esse formato; em um computador Windows, o comando funciona diretamente.

O aplicativo não envia as músicas para a internet. Os arquivos de áudio são selecionados localmente pelo usuário e reproduzidos dentro do aplicativo.
