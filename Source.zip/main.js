const { app, BrowserWindow, Menu, ipcMain } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const APP_URL_PREFIX = 'file://';
let mainWindow = null;
let pipWindow = null;

function commonWebPreferences() {
  return {
    preload: path.join(__dirname, 'preload.js'),
    contextIsolation: true,
    nodeIntegration: false,
    sandbox: true,
    webSecurity: true,
    spellcheck: false
  };
}

function secureWindow(window) {
  window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  window.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith(APP_URL_PREFIX)) event.preventDefault();
  });
  window.setMenuBarVisibility(false);
  window.removeMenu();
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 900,
    minHeight: 600,
    title: 'Lennon Audio Player',
    backgroundColor: '#070a0e',
    show: false,
    autoHideMenuBar: true,
    webPreferences: commonWebPreferences()
  });

  secureWindow(mainWindow);
  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.on('closed', () => {
    mainWindow = null;
    if (pipWindow && !pipWindow.isDestroyed()) pipWindow.close();
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));
}

function createPipWindow() {
  if (pipWindow && !pipWindow.isDestroyed()) {
    pipWindow.show();
    pipWindow.focus();
    return pipWindow;
  }

  pipWindow = new BrowserWindow({
    width: 430,
    height: 330,
    minWidth: 280,
    minHeight: 220,
    title: 'Lennon Visualizer PiP',
    backgroundColor: '#070a0e',
    show: false,
    alwaysOnTop: true,
    skipTaskbar: false,
    autoHideMenuBar: true,
    webPreferences: commonWebPreferences()
  });

  secureWindow(pipWindow);
  pipWindow.setAlwaysOnTop(true, 'floating');
  pipWindow.once('ready-to-show', () => {
    pipWindow.show();
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('pip:ready');
  });
  pipWindow.on('closed', () => {
    pipWindow = null;
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('pip:closed');
  });
  pipWindow.loadFile(path.join(__dirname, 'pip.html'));
  return pipWindow;
}

app.setAppUserModelId('com.lennon.audioplayer');

ipcMain.on('pip:open', () => createPipWindow());
ipcMain.on('pip:close', () => {
  if (pipWindow && !pipWindow.isDestroyed()) pipWindow.close();
});
ipcMain.on('pip:update', (_event, state) => {
  if (pipWindow && !pipWindow.isDestroyed() && pipWindow.webContents) {
    pipWindow.webContents.send('pip:update', state);
  }
});

ipcMain.on('pip:add-files', async (_event, paths) => {
  if (!mainWindow || mainWindow.isDestroyed() || !Array.isArray(paths)) return;
  const files = [];
  for (const filePath of paths) {
    if (typeof filePath !== 'string' || !filePath.trim()) continue;
    try {
      const data = await fs.promises.readFile(filePath);
      files.push({ path: filePath, data });
    } catch (error) {
      console.warn('Unable to read dropped file:', filePath, error.message);
    }
  }
  if (files.length) mainWindow.webContents.send('pip:add-files', files);
});

ipcMain.handle('file:read', async (_event, filePath) => {
  if (typeof filePath !== 'string' || !filePath.trim()) throw new Error('Invalid file path');
  return fs.promises.readFile(filePath);
});

ipcMain.handle('file:write', async (_event, filePath, data) => {
  if (typeof filePath !== 'string' || !filePath.trim()) throw new Error('Invalid file path');
  await fs.promises.writeFile(filePath, Buffer.from(new Uint8Array(data)));
  return true;
});

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  createMainWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
